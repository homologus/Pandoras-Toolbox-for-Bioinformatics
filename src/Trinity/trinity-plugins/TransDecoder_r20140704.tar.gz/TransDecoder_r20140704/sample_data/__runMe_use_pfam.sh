#!/bin/bash -e

./runMe.sh ../pfam/Pfam-AB.hmm.bin


