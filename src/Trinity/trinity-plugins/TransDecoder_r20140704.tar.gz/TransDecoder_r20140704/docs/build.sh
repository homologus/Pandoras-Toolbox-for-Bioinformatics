#!/bin/bash
asciidoc -a icons index.asciidoc
