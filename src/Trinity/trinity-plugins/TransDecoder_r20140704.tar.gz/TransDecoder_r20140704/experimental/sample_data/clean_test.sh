#!/bin/bash
rm -f Dmel_refseq.p?? mito_aa_inv_80.fsa.trim.p?? rDNA_nt_inv.fsa_nr.n??
rm -rf test_seq.fsa_* test_seq.fsa.* transdecoder.tmp.* test_seq.fsa.untranslated.fsa.transdecoder.*
